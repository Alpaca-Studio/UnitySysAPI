using System.IO;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SysUpdateDownloader : MonoBehaviour {
#if UNITY_EDITOR
	string _versionURL = "https://pastebin.com/raw/fcfvqrv3";
	string _sourceURL = "https://pastebin.com/raw/Rq8ZMZYU";
	string _path;
	//List<string> VC = new List<string>();
	string _currentVersion;
	
	void Start () {
		_path = Application.dataPath + "/Plugins/SysAPI/";
		_currentVersion = UnityEditor.EditorPrefs.GetString("VC");
		StartCoroutine(DownloadVC(_versionURL));
	}
	
	IEnumerator DownloadVC(string url) {
		WWW www = new WWW(url);
		yield return www;
		string file = www.text;
		//Debug.Log(www.text);
		File.Create(_path+"vc.dxt").Dispose();
		File.WriteAllText(_path+"vc.dxt", file); 
		InitDataFiles();
		
	}
	
	void InitDataFiles () { //First we read all lines of the 'repo.txt' and parse the name and url from eaching using string.Split method.
		if(File.ReadAllLines(_path+"vc.dxt")[0] != null){
			string newVC = File.ReadAllLines(_path+"vc.dxt")[0];
			if(newVC != _currentVersion){
				File.Create(Application.dataPath + "/Plugins/SysAPI/SYS_MASTER.cs").Dispose();
				StartCoroutine(DownloadDataFiles(_sourceURL,"SYS_MASTER.cs"));
				Debug.LogWarning("[Sys API]: Downloading Sys API v" + newVC);
				_currentVersion = newVC;
				UnityEditor.EditorPrefs.SetString("VC",_currentVersion);
			} else {
				Debug.LogWarning("[Sys API]: You already have the latest version." + " Sys API " + _currentVersion + ".");
				UnityEditor.EditorPrefs.SetString("VC",_currentVersion);
				Destroy(this.gameObject);
				UnityEditor.EditorApplication.isPlaying = false;
				Destroy(this.gameObject);
			}
		}
	}
	
	//Here we download the file from the parsed url above and give it a corrosponding name.
	IEnumerator DownloadDataFiles(string url, string fileName) {
		WWW www = new WWW(url);
		yield return www;
		string file = www.text;
		if(www.isDone){
			File.AppendAllText(Application.dataPath + "/Plugins/SysAPI/" + fileName, file);
			Debug.LogWarning("[Sys API]: Updated to version " + _currentVersion);
			UnityEditor.EditorPrefs.SetString("VC",_currentVersion);
			Destroy(this.gameObject);
			UnityEditor.EditorApplication.isPlaying = false;
			Destroy(this.gameObject);
		}
	}
	
	
	
	
#endif
}